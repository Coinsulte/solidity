<template>
  <div class="header-con">
    <div class="wallet-btn">
      <wallet></wallet>
    </div>

    <div style="display: none">
      <task-view></task-view>
    </div>
  </div>
</template>

<script>
import Wallet from "../../components/wallet";
import TaskView from "@/components/task";
export default {
  name: "AppHeader",
  components: {
    Wallet,
    TaskView,
  },
  methods: {
    goTo(to) {
      this.$router.push(to);
    },
    goBack() {
      window.history.go(-1);
    },
  },
};
</script>

<style lang="less" scoped>
.header-con {
  display: flex;
  align-items: center;
  background-color: #00c26f00;
  .wallet-btn {
    font-size: 12px;
    color: transparent;
    padding-left: 5px;
    padding-right: 12px;
    box-sizing: border-box;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    width: 100px;
  }
}
</style>
