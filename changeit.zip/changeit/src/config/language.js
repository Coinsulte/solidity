/** 语言包key值请参考vant3，网址：https://vant-contrib.gitee.io/vant/#/zh-CN/locale **/
export default {
    'zh-CN': {
        'copy-success': '复制成功',
        'title': 'NFT市场'
    },
    'en-US': {
        'copy-success': 'Copy successful!',
        'title': 'NFT Market'
    },
    // ...
}
